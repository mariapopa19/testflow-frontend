module.exports = {
  plugins: [
    require('@tailwindcss/postcss')
  ],
};